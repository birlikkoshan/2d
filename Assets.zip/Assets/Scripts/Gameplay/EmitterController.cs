using UnityEngine;

/// <summary>
/// Marks a cell as a beam emitter and stores its firing direction.
/// Direction is derived automatically from the object's rotation set by GridManager.
/// GridX / GridY are assigned by GridManager after instantiation.
///
/// Rotation → Direction mapping (same as local +Y of EmitterGraphic after Z rotation):
///   Z =   0° → UP    (0, 1)
///   Z = -90° → RIGHT (1, 0)   ← used in all current levels
///   Z =  90° → LEFT  (-1, 0)
///   Z = 180° → DOWN  (0, -1)
/// </summary>
public class EmitterController : MonoBehaviour
{
    /// <summary>Grid X coordinate — set by GridManager.BuildGrid() after instantiation.</summary>
    public int GridX;

    /// <summary>Grid Y coordinate — set by GridManager.BuildGrid() after instantiation.</summary>
    public int GridY;

    /// <summary>Beam direction in grid space; set by <see cref="RefreshDirectionFromTransform"/> after GridManager applies rotation.</summary>
    public Vector2Int Direction { get; private set; }

    // ════════════════════════════════════════════════════════════════════════
    /// <summary>
    /// Call after <c>RectTransform.localRotation</c> is set (e.g. from <see cref="GridManager.BuildGrid"/>).
    /// Cannot run in <c>Awake</c>: <c>Instantiate</c> invokes <c>Awake</c> before GridManager assigns <c>cell.rotation</c>.
    /// </summary>
    public void RefreshDirectionFromTransform()
    {
        // Graphic points along local +Y; same mapping as before.
        float angleRad = transform.localEulerAngles.z * Mathf.Deg2Rad;
        float dx = -Mathf.Sin(angleRad);
        float dy =  Mathf.Cos(angleRad);

        Direction = new Vector2Int(Mathf.RoundToInt(dx), Mathf.RoundToInt(dy));
        if (Direction == Vector2Int.zero)
            Direction = new Vector2Int(1, 0);
    }
}
